export class CreateBarangDto {
    kode_barang: string;
    nama_barang: string;
    merk: string;
    seri: string;
    thn_perolehan: string;
    ket_barang: string;
    lisensi: string;
    nup: string;
    no_bmn: string;
    kondisi_barang: string;
    status_barang: string;
    img_barang: string;
}
