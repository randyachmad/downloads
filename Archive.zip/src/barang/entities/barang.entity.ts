import { JenisAset } from "src/jenis-aset/entities/jenis-aset.entity";
import { Column, CreateDateColumn, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Barang {
    @PrimaryGeneratedColumn('increment')
    id_barang: number;

    @Column({type: 'varchar', unique: true, nullable: false})
    public kode_barang: string;

    @Column({type: 'varchar', unique: true, nullable: false})
    public nama_barang: string;

    @Column({type: 'varchar'})
    public merk: string;

    @Column({type: 'varchar'})
    public seri: string;

    @Column({type: 'varchar'})
    public thn_perolehan: string;

    @Column({type: 'varchar'})
    public ket_barang: string;

    @Column({type: 'varchar'})
    public lisensi: string;

    @Column({type: 'varchar'})
    public nup: string;

    @Column({type: 'varchar'})
    public no_bmn: string;

    @Column({type: 'varchar'})
    public kondisi_barang: string;

    @Column({type: 'varchar'})
    public status_barang: string;

    @Column({type: 'varchar'})
    public img_barang: string;

    @CreateDateColumn({type:"timestamp", default: () => "NOW()" })
    public created_at: Date;

    @UpdateDateColumn({type: "timestamp", default: () => "NOW()", onUpdate: "NOW()"})
    public updated_at: Date;

    @OneToOne(() => JenisAset)
    @JoinColumn()
    jenisaset: JenisAset
}
