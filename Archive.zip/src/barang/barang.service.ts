import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateBarangDto } from './dto/create-barang.dto';
import { UpdateBarangDto } from './dto/update-barang.dto';
import { Barang } from './entities/barang.entity';

@Injectable()
export class BarangService {
  constructor (@InjectRepository (Barang)
  private readonly userRepository: Repository<Barang>){}

  //SERVICE CREATE
  create (data: CreateBarangDto) {
    console.log(CreateBarangDto)
    const barang = new Barang();

    barang.kode_barang = data.kode_barang;
    barang.nama_barang = data.nama_barang;
    barang.merk = data.merk;
    barang.seri = data.seri;
    barang.thn_perolehan = data.thn_perolehan;
    barang.ket_barang = data.ket_barang;
    barang.lisensi = data.lisensi;
    barang.nup = data.nup;
    barang.no_bmn = data.no_bmn;
    barang.kondisi_barang = data.kondisi_barang;
    barang.status_barang = data.status_barang;
    barang.img_barang = data.img_barang;

    console.log(barang)
    return this.userRepository.save(barang);

  }


  //Method Select All
  findAll() {
    return this.userRepository.find();
  }

  //Method Select
  findOne(id: number) {
    return this.userRepository.findOneOrFail(id);
  }

  //Method Update
  update(data: CreateBarangDto, id: number) {
    // return this.userRepository.save({... data, id: Number(id)});
    var filename = "gambar.jpg"

    if (data.img_barang != null) {
      filename = data.img_barang
    }

    return this.userRepository.save({kode_barang: data.kode_barang, nama_barang: data.nama_barang,
      merk: data.merk, seri: data.seri, thn_perolehan: data.thn_perolehan, ket_barang: data.ket_barang,
      lisensi: data.lisensi, nup: data.nup, no_bmn: data.no_bmn, kondisi_barang: data.kondisi_barang,
      status_barang: data.status_barang, img_barang: filename, id: Number(id)});
  }

  //Method Delete
  delete(id: number) {
    return this.userRepository.delete(id);
  }

}
