import { Controller, Get, Post, Body, Patch, Param, Delete, Put, UseInterceptors, UploadedFiles, UploadedFile } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { BarangService } from './barang.service';
import { CreateBarangDto } from './dto/create-barang.dto';
import { UpdateBarangDto } from './dto/update-barang.dto';

@Controller('barang')
export class BarangController {
  constructor(private readonly barangService: BarangService) {}

  @Post()
  @UseInterceptors(FileInterceptor('img_barang'))
  async create(@UploadedFile() file: Express.Multer.File, @Body() data: CreateBarangDto) {
    return {
      data: await this.barangService.create(data)
    }
  }

  @Get()
  async findAll() {
    return {
      data: await this.barangService.findAll()
    };
  }

  @Get(':id')
  async findOne(@Param('id') id: number) {
    return {
      data: await this.barangService.findOne(id)
    }
  }

  @Put(':id')
  async update(@Body() data: CreateBarangDto, @Param('id') id: number) {
    return {
      data: await this.barangService.update(data, id)
    }
  }

  @Delete(':id')
  async remove(@Param('id') id:number){
    return this.barangService.delete(id);
  }
}
