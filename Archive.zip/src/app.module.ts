import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { join } from 'path';
import { JenisAset } from './jenis-aset/entities/jenis-aset.entity';
import { JenisAsetController } from './jenis-aset/jenis-aset.controller';
import { JenisAsetModule } from './jenis-aset/jenis-aset.module';
import { JenisAsetService } from './jenis-aset/jenis-aset.service';
import { config } from './orm.config';
import { DataRuanganModule } from './data_ruangan/data_ruangan.module';
import { DataRuanganController } from './data_ruangan/data_ruangan.controller';
import { DataRuanganService } from './data_ruangan/data_ruangan.service';
import { BarangModule } from './barang/barang.module';

@Module({
  imports: [TypeOrmModule.forRoot(config),JenisAsetModule, DataRuanganModule, BarangModule],
  controllers: [JenisAsetController,DataRuanganController],
  providers: [JenisAsetService,DataRuanganService],
})
export class AppModule {}
