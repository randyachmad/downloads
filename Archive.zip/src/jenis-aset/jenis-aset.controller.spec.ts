import { Test, TestingModule } from '@nestjs/testing';
import { JenisAsetController } from './jenis-aset.controller';
import { JenisAsetService } from './jenis-aset.service';

describe('JenisAsetController', () => {
  let controller: JenisAsetController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [JenisAsetController],
      providers: [JenisAsetService],
    }).compile();

    controller = module.get<JenisAsetController>(JenisAsetController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
