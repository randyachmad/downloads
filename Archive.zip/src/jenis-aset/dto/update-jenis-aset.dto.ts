import { PartialType } from '@nestjs/mapped-types';
import { CreateJenisAsetDto } from './create-jenis-aset.dto';

export class UpdateJenisAsetDto extends PartialType(CreateJenisAsetDto) {}
