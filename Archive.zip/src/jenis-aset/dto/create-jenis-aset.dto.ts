export class CreateJenisAsetDto {}
