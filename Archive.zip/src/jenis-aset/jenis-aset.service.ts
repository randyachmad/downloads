import { Injectable } from '@nestjs/common';
import { CreateJenisAsetDto } from './dto/create-jenis-aset.dto';
import { UpdateJenisAsetDto } from './dto/update-jenis-aset.dto';

@Injectable()
export class JenisAsetService {
  create(createJenisAsetDto: CreateJenisAsetDto) {
    return 'This action adds a new jenisAset';
  }

  findAll() {
    return `This action returns all jenisAset`;
  }

  findOne(id: number) {
    return `This action returns a #${id} jenisAset`;
  }

  update(id: number, updateJenisAsetDto: UpdateJenisAsetDto) {
    return `This action updates a #${id} jenisAset`;
  }

  remove(id: number) {
    return `This action removes a #${id} jenisAset`;
  }
}
