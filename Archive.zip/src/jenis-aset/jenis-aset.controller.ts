import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { JenisAsetService } from './jenis-aset.service';
import { CreateJenisAsetDto } from './dto/create-jenis-aset.dto';
import { UpdateJenisAsetDto } from './dto/update-jenis-aset.dto';

@Controller('jenis-aset')
export class JenisAsetController {
  constructor(private readonly jenisAsetService: JenisAsetService) {}

  @Post()
  create(@Body() createJenisAsetDto: CreateJenisAsetDto) {
    return this.jenisAsetService.create(createJenisAsetDto);
  }

  @Get()
  findAll() {
    return this.jenisAsetService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.jenisAsetService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateJenisAsetDto: UpdateJenisAsetDto) {
    return this.jenisAsetService.update(+id, updateJenisAsetDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.jenisAsetService.remove(+id);
  }
}
