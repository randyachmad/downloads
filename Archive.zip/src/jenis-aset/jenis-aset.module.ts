import { Module } from '@nestjs/common';
import { JenisAsetService } from './jenis-aset.service';
import { JenisAsetController } from './jenis-aset.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JenisAset } from './entities/jenis-aset.entity';

@Module({
  imports: [TypeOrmModule.forFeature([JenisAset])],
  controllers: [JenisAsetController],
  providers: [JenisAsetService]
})
export class JenisAsetModule {}
