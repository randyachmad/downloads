import { Test, TestingModule } from '@nestjs/testing';
import { JenisAsetService } from './jenis-aset.service';

describe('JenisAsetService', () => {
  let service: JenisAsetService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [JenisAsetService],
    }).compile();

    service = module.get<JenisAsetService>(JenisAsetService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
