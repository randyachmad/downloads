import { Injectable } from '@nestjs/common';
import { CreateDataRuanganDto } from './dto/create-data_ruangan.dto';
import { UpdateDataRuanganDto } from './dto/update-data_ruangan.dto';

@Injectable()
export class DataRuanganService {
  create(createDataRuanganDto: CreateDataRuanganDto) {
    return 'This action adds a new dataRuangan';
  }

  findAll() {
    return `This action returns all dataRuangan`;
  }

  findOne(id: number) {
    return `This action returns a #${id} dataRuangan`;
  }

  update(id: number, updateDataRuanganDto: UpdateDataRuanganDto) {
    return `This action updates a #${id} dataRuangan`;
  }

  remove(id: number) {
    return `This action removes a #${id} dataRuangan`;
  }
}
