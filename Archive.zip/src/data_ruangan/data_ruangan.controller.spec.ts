import { Test, TestingModule } from '@nestjs/testing';
import { DataRuanganController } from './data_ruangan.controller';
import { DataRuanganService } from './data_ruangan.service';

describe('DataRuanganController', () => {
  let controller: DataRuanganController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DataRuanganController],
      providers: [DataRuanganService],
    }).compile();

    controller = module.get<DataRuanganController>(DataRuanganController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
