import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class DataRuangan {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column({type: 'varchar', unique: true, nullable: false})
    public kode_ruangan: string;

    @Column({type: 'varchar', unique: true, nullable: false})
    public nama_ruangan: string;

    @Column({type: 'varchar'})
    public kapasitas_ruangan: string;

    @Column({type: 'varchar'})
    public ket_ruangan: string;

    @Column({type: 'varchar'})
    public status_ruangan: string;

    @CreateDateColumn({type:"timestamp", default: () => "NOW()" })
    public created_at: Date;

    @UpdateDateColumn({type: "timestamp", default: () => "NOW()", onUpdate: "NOW()"})
    public updated_at: Date;
}
