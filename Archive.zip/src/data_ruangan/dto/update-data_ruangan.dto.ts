import { PartialType } from '@nestjs/mapped-types';
import { CreateDataRuanganDto } from './create-data_ruangan.dto';

export class UpdateDataRuanganDto extends PartialType(CreateDataRuanganDto) {}
