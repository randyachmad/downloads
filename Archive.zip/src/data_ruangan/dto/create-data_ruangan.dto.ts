export class CreateDataRuanganDto {}
