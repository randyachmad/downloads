import { Module } from '@nestjs/common';
import { DataRuanganService } from './data_ruangan.service';
import { DataRuanganController } from './data_ruangan.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DataRuangan } from './entities/data_ruangan.entity';

@Module({
  imports: [TypeOrmModule.forFeature([DataRuangan])],
  controllers: [DataRuanganController],
  providers: [DataRuanganService]
})
export class DataRuanganModule {}
