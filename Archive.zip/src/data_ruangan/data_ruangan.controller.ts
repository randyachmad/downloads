import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { DataRuanganService } from './data_ruangan.service';
import { CreateDataRuanganDto } from './dto/create-data_ruangan.dto';
import { UpdateDataRuanganDto } from './dto/update-data_ruangan.dto';

@Controller('data-ruangan')
export class DataRuanganController {
  constructor(private readonly dataRuanganService: DataRuanganService) {}

  @Post()
  create(@Body() createDataRuanganDto: CreateDataRuanganDto) {
    return this.dataRuanganService.create(createDataRuanganDto);
  }

  @Get()
  findAll() {
    return this.dataRuanganService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.dataRuanganService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateDataRuanganDto: UpdateDataRuanganDto) {
    return this.dataRuanganService.update(+id, updateDataRuanganDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.dataRuanganService.remove(+id);
  }
}
