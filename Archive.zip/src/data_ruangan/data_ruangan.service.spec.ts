import { Test, TestingModule } from '@nestjs/testing';
import { DataRuanganService } from './data_ruangan.service';

describe('DataRuanganService', () => {
  let service: DataRuanganService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [DataRuanganService],
    }).compile();

    service = module.get<DataRuanganService>(DataRuanganService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
